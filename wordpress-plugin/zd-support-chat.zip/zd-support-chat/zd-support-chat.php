<?php
/**
 * Plugin Name: REACHRIGHT Support Chat
 * Description: Website support chat for site admins, inside the WordPress dashboard. Step-by-step answers, help guides, video walkthroughs and a ticket form, provided by REACHRIGHT Studios.
 * Version:     1.3.0
 * Author:      REACHRIGHT Studios
 * Requires at least: 5.8
 * Requires PHP: 7.2
 * License:     GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ZD_Support_Chat {
	const VERSION = '1.3.0';
	const SLUG    = 'zd-support-chat';

	/* ---- Managed by REACHRIGHT Studios (not editable from WordPress) ---- */
	const FIREBASE_PROJECT = 'rr-chat-support';
	const FIREBASE_KEY     = 'AIzaSyDJaO0kBPTMBeTgyy_-DAe8gIQ_H2SCFv8';
	const SUPPORT_EMAIL    = 'support@reachrightstudios.com';
	const UPDATE_BASE      = 'https://YOUR-GITHUB-NAME.github.io/reachright-support-chat/'; // GitHub Pages address
	const AUDIENCE         = 'manage_options'; // administrators only

	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'wp_ajax_zdsc_ticket', array( __CLASS__, 'ticket' ) );
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'check_update' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'plugin_info' ), 20, 3 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'clear_update_cache' ), 10, 0 );
		add_action( 'load-update-core.php', array( __CLASS__, 'maybe_force_check' ) );
		register_activation_hook( __FILE__, array( __CLASS__, 'cleanup_old_versions' ) );
		add_action( 'admin_init', array( __CLASS__, 'cleanup_old_versions' ) );
	}

	// Earlier versions had a settings page and uploads; remove what they left behind (runs once).
	public static function cleanup_old_versions() {
		if ( get_option( 'zdsc_cleaned' ) === self::VERSION ) {
			return;
		}
		delete_option( 'zdsc_settings' );
		$up  = wp_upload_dir();
		$dir = trailingslashit( $up['basedir'] ) . 'zd-support-chat';
		foreach ( array( 'kb.json', 'index.php' ) as $f ) {
			if ( file_exists( $dir . '/' . $f ) ) {
				wp_delete_file( $dir . '/' . $f );
			}
		}
		if ( is_dir( $dir ) ) {
			@rmdir( $dir ); // phpcs:ignore
		}
		update_option( 'zdsc_cleaned', self::VERSION, false );
	}

	/* ---------------- The chat, in the dashboard ---------------- */

	public static function enqueue( $hook = '' ) {
		if ( ! is_user_logged_in() || ! current_user_can( self::AUDIENCE ) ) {
			return;
		}
		// Stay out of the way in the page/post editors and Cornerstone.
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$page   = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore
		if ( ( $screen && method_exists( $screen, 'is_block_editor' ) && $screen->is_block_editor() ) || false !== strpos( $page, 'cornerstone' ) || in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}
		$user  = wp_get_current_user();
		$first = $user->first_name ? $user->first_name : $user->display_name;
		wp_enqueue_script( 'zd-support-chat', plugins_url( 'assets/support-chat.js', __FILE__ ), array(), self::VERSION, true );
		$cfg = array(
			'firebaseProject' => self::FIREBASE_PROJECT,
			'firebaseKey'     => self::FIREBASE_KEY,
			'kb'              => plugins_url( 'assets/kb.json', __FILE__ ) . '?v=' . self::VERSION, // backup copy if Firebase can't be reached
			'title'           => 'Website support',
			'greeting'        => ( $first ? 'Hi ' . $first . '! ' : 'Hi! ' ) . "Ask me how to update your website or fix a problem, and I'll walk you through it step by step.",
			'color'           => '#0e78a8',
			'theme'           => 'light',
			'supportEmail'    => self::SUPPORT_EMAIL,
			'ticketEndpoint'  => admin_url( 'admin-ajax.php?action=zdsc_ticket' ),
			'nonce'           => wp_create_nonce( 'zdsc_ticket' ),
			'userName'        => $user->display_name,
			'userEmail'       => $user->user_email,
			'siteLabel'       => get_bloginfo( 'name' ) . ', ' . home_url(),
			'suggestions'     => 'How do I update the footer?|How do I add an event?|How do I add or replace a photo?',
		);
		wp_add_inline_script( 'zd-support-chat', 'window.SupportChatConfig=' . wp_json_encode( $cfg ) . ';', 'before' );
	}

	/* ---------------- Ticket form → email to REACHRIGHT support ---------------- */

	public static function ticket() {
		if ( ! is_user_logged_in() || ! current_user_can( self::AUDIENCE ) || ! check_ajax_referer( 'zdsc_ticket', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'Please reload the page and try again.' ), 403 );
		}
		if ( ! empty( $_POST['company_site'] ) || (int) ( $_POST['elapsed'] ?? 0 ) < 3000 ) { // phpcs:ignore
			wp_send_json_success();
		}
		$key = 'zdsc_rl_' . get_current_user_id();
		$n   = (int) get_transient( $key );
		if ( $n >= 10 ) {
			wp_send_json_error( array( 'message' => 'Too many requests. Please try again later.' ), 429 );
		}
		set_transient( $key, $n + 1, HOUR_IN_SECONDS );

		$clean   = function ( $v, $max ) { return mb_substr( trim( preg_replace( '/[\r\n]+/', ' ', sanitize_text_field( wp_unslash( $v ) ) ) ), 0, $max ); };
		$name    = $clean( $_POST['name'] ?? '', 100 ); // phpcs:ignore
		$email   = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ); // phpcs:ignore
		$website = $clean( $_POST['website'] ?? '', 200 ); // phpcs:ignore
		$page    = esc_url_raw( wp_unslash( $_POST['page'] ?? '' ) ); // phpcs:ignore
		$message = mb_substr( sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) ), 0, 5000 ); // phpcs:ignore
		$chat    = mb_substr( sanitize_textarea_field( wp_unslash( $_POST['transcript'] ?? '' ) ), 0, 8000 ); // phpcs:ignore
		$urgent  = ! empty( $_POST['urgent'] ); // phpcs:ignore

		if ( '' === $name || ! is_email( $email ) || mb_strlen( $message ) < 5 ) {
			wp_send_json_error( array( 'message' => 'Please fill in your name, a valid email and your message.' ), 400 );
		}

		$user    = wp_get_current_user();
		$theme   = wp_get_theme();
		$parent  = $theme->parent() ? ' (child of ' . $theme->parent()->get( 'Name' ) . ' ' . $theme->parent()->get( 'Version' ) . ')' : '';
		$subject = ( $urgent ? 'URGENT: Website Down - ' : 'Chat request: ' ) . mb_substr( preg_replace( '/\s+/', ' ', $message ), 0, 70 );
		$body    = "New support request from the website chat\n\n"
			. "Name: $name\nEmail: $email\n"
			. ( $website ? "Church / website: $website\n" : '' )
			. ( $page ? "Sent from page: $page\n" : '' )
			. "\nMessage:\n$message\n"
			. ( $chat ? "\n--- Chat conversation ---\n$chat\n" : '' )
			. "\n--- Site details ---\n"
			. 'Site: ' . get_bloginfo( 'name' ) . ' — ' . home_url() . "\n"
			. 'Logged-in user: ' . $user->user_login . ' (' . implode( ', ', (array) $user->roles ) . ")\n"
			. 'WordPress: ' . get_bloginfo( 'version' ) . ' · PHP: ' . PHP_VERSION . "\n"
			. 'Theme: ' . $theme->get( 'Name' ) . ' ' . $theme->get( 'Version' ) . $parent . "\n"
			. 'Active plugins: ' . count( (array) get_option( 'active_plugins', array() ) ) . "\n"
			. 'Support Chat plugin: ' . self::VERSION . "\n";
		$headers = array( 'Reply-To: ' . $name . ' <' . $email . '>' );

		if ( wp_mail( self::SUPPORT_EMAIL, $subject, $body, $headers ) ) {
			wp_send_json_success();
		}
		wp_send_json_error( array( 'message' => 'Email could not be sent.' ), 500 );
	}

	/* ---------------- Updates from GitHub ---------------- */

	private static function update_base() {
		return ( 0 === strpos( self::UPDATE_BASE, 'https://' ) && false === strpos( self::UPDATE_BASE, 'YOUR-GITHUB-NAME' ) ) ? trailingslashit( self::UPDATE_BASE ) : '';
	}

	// Reads wordpress-plugin/update.json from GitHub Pages (cached for 6 hours).
	private static function manifest() {
		$base = self::update_base();
		if ( '' === $base ) {
			return null;
		}
		$cached = get_transient( 'zdsc_update_manifest' );
		if ( false !== $cached ) {
			return is_array( $cached ) ? $cached : null;
		}
		$res = wp_remote_get( $base . 'wordpress-plugin/update.json', array( 'timeout' => 10 ) );
		$m   = null;
		if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
			$m = json_decode( wp_remote_retrieve_body( $res ), true );
		}
		if ( is_array( $m ) && ! empty( $m['download_url'] ) && ! preg_match( '#^https?://#i', $m['download_url'] ) ) {
			$m['download_url'] = $base . ltrim( $m['download_url'], '/' );
		}
		// Only accept a download from the same GitHub Pages site.
		if ( ! is_array( $m ) || empty( $m['version'] ) || empty( $m['download_url'] ) || 0 !== strpos( $m['download_url'], $base ) ) {
			set_transient( 'zdsc_update_manifest', 'none', HOUR_IN_SECONDS );
			return null;
		}
		set_transient( 'zdsc_update_manifest', $m, 6 * HOUR_IN_SECONDS );
		return $m;
	}

	private static function update_item( $m ) {
		return (object) array(
			'id'           => self::update_base(),
			'slug'         => self::SLUG,
			'plugin'       => plugin_basename( __FILE__ ),
			'new_version'  => (string) $m['version'],
			'url'          => self::update_base(),
			'package'      => (string) $m['download_url'],
			'requires'     => isset( $m['requires'] ) ? (string) $m['requires'] : '',
			'tested'       => isset( $m['tested'] ) ? (string) $m['tested'] : '',
			'requires_php' => isset( $m['requires_php'] ) ? (string) $m['requires_php'] : '',
			'icons'        => array(),
		);
	}

	public static function check_update( $transient ) {
		if ( ! is_object( $transient ) || empty( $transient->checked ) ) {
			return $transient;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $transient;
		}
		$file = plugin_basename( __FILE__ );
		if ( version_compare( (string) $m['version'], self::VERSION, '>' ) ) {
			$transient->response[ $file ] = self::update_item( $m );
		} else {
			$transient->no_update[ $file ] = self::update_item( $m );
		}
		return $transient;
	}

	public static function plugin_info( $res, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
			return $res;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $res;
		}
		return (object) array(
			'name'          => 'REACHRIGHT Support Chat',
			'slug'          => self::SLUG,
			'version'       => (string) $m['version'],
			'author'        => 'REACHRIGHT Studios',
			'homepage'      => self::update_base(),
			'requires'      => isset( $m['requires'] ) ? (string) $m['requires'] : '',
			'tested'        => isset( $m['tested'] ) ? (string) $m['tested'] : '',
			'requires_php'  => isset( $m['requires_php'] ) ? (string) $m['requires_php'] : '',
			'last_updated'  => isset( $m['last_updated'] ) ? (string) $m['last_updated'] : '',
			'download_link' => (string) $m['download_url'],
			'sections'      => isset( $m['sections'] ) && is_array( $m['sections'] ) ? $m['sections'] : array( 'changelog' => '' ),
		);
	}

	public static function clear_update_cache() {
		delete_transient( 'zdsc_update_manifest' );
	}

	public static function maybe_force_check() {
		if ( isset( $_GET['force-check'] ) ) { // phpcs:ignore
			delete_transient( 'zdsc_update_manifest' );
		}
	}
}

ZD_Support_Chat::init();
