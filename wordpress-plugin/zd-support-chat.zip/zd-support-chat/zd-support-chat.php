<?php
/**
 * Plugin Name: REACHRIGHT Support Chat
 * Plugin URI:  https://reachrightstudios.com/support/
 * Description: Website help for your team, right in the dashboard: step-by-step answers, video guides and quick support requests from REACHRIGHT Studios.
 * Version:     1.18.1
 * Author:      REACHRIGHT Studios
 * Author URI:  https://reachrightstudios.com/
 * Requires at least: 5.8
 * Requires PHP: 7.2
 * License:     GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ZD_Support_Chat {
	const VERSION = '1.18.1';
	const SLUG    = 'zd-support-chat';

	/* ---- Managed by REACHRIGHT Studios (not editable from WordPress) ---- */
	const FIREBASE_PROJECT = 'rr-chat-support';
	const FIREBASE_KEY     = 'AIzaSyDJaO0kBPTMBeTgyy_-DAe8gIQ_H2SCFv8';
	const SUPPORT_EMAIL    = 'support@reachrightstudios.com';
	const UPDATE_BASE      = 'https://mariolclaramojr-lgtm.github.io/reachright-support-chat/'; // GitHub Pages address
	const AUDIENCE         = 'manage_options'; // administrators only
	const TICKET_COOLDOWN  = 300;              // seconds between support requests (5 minutes)

	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_front' ) );
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 999 );
		// Cornerstone builder (/cornerstone/edit/…): print the chat at the first of these that runs.
		add_action( 'wp_head', array( __CLASS__, 'builder_print' ), 999 );
		add_action( 'wp_footer', array( __CLASS__, 'builder_print' ), 999 );
		add_action( 'admin_footer', array( __CLASS__, 'builder_print' ), 999 );
		add_action( 'shutdown', array( __CLASS__, 'builder_print' ), 0 );
		add_action( 'wp_ajax_zdsc_ticket', array( __CLASS__, 'ticket' ) );
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'check_update' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'plugin_info' ), 20, 3 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'clear_update_cache' ), 10, 0 );
		add_action( 'load-update-core.php', array( __CLASS__, 'maybe_force_check' ) );
		add_filter( 'plugin_row_meta', array( __CLASS__, 'row_links' ), 10, 2 );
		register_activation_hook( __FILE__, array( __CLASS__, 'cleanup_old_versions' ) );
		add_action( 'admin_init', array( __CLASS__, 'cleanup_old_versions' ) );
	}

	// Earlier versions had a settings page and uploads; remove what they left behind (runs once).
	public static function cleanup_old_versions() {
		if ( get_option( 'zdsc_cleaned' ) === self::VERSION ) {
			return;
		}
		delete_option( 'zdsc_settings' );
		$up  = wp_upload_dir();
		$dir = trailingslashit( $up['basedir'] ) . 'zd-support-chat';
		foreach ( array( 'kb.json', 'index.php' ) as $f ) {
			if ( file_exists( $dir . '/' . $f ) ) {
				wp_delete_file( $dir . '/' . $f );
			}
		}
		if ( is_dir( $dir ) ) {
			@rmdir( $dir ); // phpcs:ignore
		}
		update_option( 'zdsc_cleaned', self::VERSION, false );
	}

	/* ---------------- The chat, in the dashboard ---------------- */

	private static function allowed() {
		return is_user_logged_in() && current_user_can( self::AUDIENCE );
	}

	// "Need help?" in the black WordPress bar, on the dashboard and on the live site.
	public static function admin_bar( $bar ) {
		if ( ! self::allowed() ) {
			return;
		}
		$icon = '<svg class="zdsc-ab-icon" viewBox="0 0 34 38" aria-hidden="true"><g fill="#189ad0"><polygon points="8,1 16.2,1 13.7,11.6 11.1,11.6"/><path d="M25.2,9H30.6C31.6,9 31.9,9.8 31.6,10.9L30.3,15.6C30,16.6 29.3,17.1 28.4,17.1H23L24.1,10.4C24.3,9.5 24.7,9 25.2,9Z"/><path d="M6.3,20.6H12L10.9,27.3C10.7,28.2 10.2,28.6 9.6,28.6H4.4C3.4,28.6 3.1,27.8 3.4,26.8L4.7,22C5,21.1 5.5,20.6 6.3,20.6Z"/><polygon points="21,26.2 24.2,26.2 27.1,37.6 18.9,37.6"/></g></svg>';
		$bar->add_node(
			array(
				'id'    => 'zdsc-help',
				'title' => $icon . '<span class="ab-label">Need help?</span>',
				'href'  => '#',
				'meta'  => array( 'title' => 'Open REACHRIGHT Support' ),
			)
		);
	}

	private static function admin_bar_css() {
		return '#wpadminbar #wp-admin-bar-zdsc-help > .ab-item{display:flex;align-items:center;gap:6px}'
			. '#wpadminbar #wp-admin-bar-zdsc-help .zdsc-ab-icon{width:14px;height:16px;flex:none}'
			. '#wpadminbar #wp-admin-bar-zdsc-help .ab-label{font-weight:600}'
			. '@media screen and (max-width:782px){#wpadminbar #wp-admin-bar-zdsc-help{display:block}#wpadminbar #wp-admin-bar-zdsc-help > .ab-item{padding:0 12px;height:46px}#wpadminbar #wp-admin-bar-zdsc-help .zdsc-ab-icon{width:22px;height:25px}#wpadminbar #wp-admin-bar-zdsc-help .ab-label{display:none}}';
	}

	private static function config( $hide_launcher ) {
		$user  = wp_get_current_user();
		$first = $user->first_name ? $user->first_name : $user->display_name;
		return array(
			'firebaseProject' => self::FIREBASE_PROJECT,
			'firebaseKey'     => self::FIREBASE_KEY,
			'kb'              => plugins_url( 'assets/kb.json', __FILE__ ) . '?v=' . self::VERSION, // backup copy if Firebase can't be reached
			'title'           => 'REACHRIGHT SUPPORT',
			'greeting'        => ( $first ? 'Hi ' . $first . '! ' : 'Hi! ' ) . 'How can we help you today?',
			'color'           => '#0e78a8',
			'theme'           => 'light',
			'hideLauncher'    => $hide_launcher ? 'true' : 'false',
			'supportEmail'    => self::SUPPORT_EMAIL,
			'ticketEndpoint'  => admin_url( 'admin-ajax.php?action=zdsc_ticket' ),
			'nonce'           => wp_create_nonce( 'zdsc_ticket' ),
			'userName'        => $user->display_name,
			'userEmail'       => $user->user_email,
			'siteLabel'       => get_bloginfo( 'name' ) . ', ' . home_url(),
			'ticketCooldown'  => self::TICKET_COOLDOWN / 60,
			'downChip'        => 'Page error or not loading',
			'attachments'     => 'true',
		);
	}

	private static function load( $hide_launcher ) {
		if ( self::is_builder() ) {
			return; // the builder gets its own copy (builder_print)
		}
		wp_enqueue_script( 'zd-support-chat', plugins_url( 'assets/support-chat.js', __FILE__ ), array(), self::VERSION, true );
		wp_add_inline_script( 'zd-support-chat', 'window.SupportChatConfig=' . wp_json_encode( self::config( $hide_launcher ) ) . ';', 'before' );
		wp_add_inline_style( 'admin-bar', self::admin_bar_css() );
	}

	private static function is_builder() {
		if ( wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || 'GET' !== ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) { // phpcs:ignore
			return false;
		}
		$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : ''; // phpcs:ignore
		return (bool) preg_match( '#/cornerstone/edit(/|$)#', $path );
	}

	// Cornerstone builder: chat on the left (panels are on the right), button next to Save.
	public static function builder_print() {
		static $done = false;
		if ( $done || ! self::is_builder() || ! self::allowed() ) {
			return;
		}
		if ( 'shutdown' === current_action() ) {
			foreach ( headers_list() as $h ) {   // only add to HTML pages
				if ( 0 === stripos( $h, 'content-type:' ) && false === stripos( $h, 'text/html' ) ) {
					return;
				}
			}
		}
		$done = true;
		$cfg  = self::config( true );
		$cfg['position']  = 'left';
		$cfg['csToolbar'] = 'true';
		echo "\n<script>window.SupportChatConfig=" . wp_json_encode( $cfg ) . ";</script>\n"; // phpcs:ignore
		echo '<script src="' . esc_url( plugins_url( 'assets/support-chat.js', __FILE__ ) . '?ver=' . self::VERSION ) . '" defer></script>' . "\n"; // phpcs:ignore
	}

	// Dashboard: floating button, except in the page/post editors and Cornerstone (top bar only there).
	public static function enqueue( $hook = '' ) {
		if ( ! self::allowed() ) {
			return;
		}
		$screen    = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$page      = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore
		$in_editor = ( $screen && method_exists( $screen, 'is_block_editor' ) && $screen->is_block_editor() ) || false !== strpos( $page, 'cornerstone' ) || in_array( $hook, array( 'post.php', 'post-new.php' ), true );
		self::load( $in_editor );
	}

	// Live site: only for logged-in admins who can see the top bar; opened from "Need help?".
	public static function enqueue_front() {
		if ( ! self::allowed() || ! is_admin_bar_showing() || is_customize_preview() ) {
			return;
		}
		self::load( true );
	}

	/* ---------------- Ticket form → email to REACHRIGHT support ---------------- */

	public static function ticket() {
		if ( ! is_user_logged_in() || ! current_user_can( self::AUDIENCE ) || ! check_ajax_referer( 'zdsc_ticket', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'Please reload the page and try again.' ), 403 );
		}
		if ( ! empty( $_POST['company_site'] ) || (int) ( $_POST['elapsed'] ?? 0 ) < 3000 ) { // phpcs:ignore
			wp_send_json_success();
		}
		// One request every 5 minutes per admin.
		$cool = 'zdsc_cool_' . get_current_user_id();
		$next = (int) get_transient( $cool );
		if ( $next > time() ) {
			wp_send_json_error( array( 'message' => 'Please wait before sending another request.', 'wait' => $next - time() ), 429 );
		}
		$key = 'zdsc_rl_' . get_current_user_id();
		$n   = (int) get_transient( $key );
		if ( $n >= 10 ) {
			wp_send_json_error( array( 'message' => 'Too many requests. Please try again later.' ), 429 );
		}
		set_transient( $key, $n + 1, HOUR_IN_SECONDS );

		$clean   = function ( $v, $max ) { return mb_substr( trim( preg_replace( '/[\r\n]+/', ' ', sanitize_text_field( wp_unslash( $v ) ) ) ), 0, $max ); };
		$name    = $clean( $_POST['name'] ?? '', 100 ); // phpcs:ignore
		$email   = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ); // phpcs:ignore
		$website = $clean( $_POST['website'] ?? '', 200 ); // phpcs:ignore
		$page    = esc_url_raw( wp_unslash( $_POST['page'] ?? '' ) ); // phpcs:ignore
		$message = mb_substr( sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) ), 0, 5000 ); // phpcs:ignore
		$chat    = mb_substr( sanitize_textarea_field( wp_unslash( $_POST['transcript'] ?? '' ) ), 0, 8000 ); // phpcs:ignore
		$urgent  = ! empty( $_POST['urgent'] ); // phpcs:ignore

		if ( '' === $name || ! is_email( $email ) || mb_strlen( $message ) < 5 ) {
			wp_send_json_error( array( 'message' => 'Please fill in your name, a valid email and your message.' ), 400 );
		}

		// Screenshots: up to 3 images, 5 MB each, checked to be real images, kept only until the email is sent.
		list( $attachments, $tmp_dir, $skipped ) = self::collect_screenshots();

		$user    = wp_get_current_user();
		$theme   = wp_get_theme();
		$parent  = $theme->parent() ? ' (child of ' . $theme->parent()->get( 'Name' ) . ' ' . $theme->parent()->get( 'Version' ) . ')' : '';
		$subject = ( $urgent ? 'URGENT: Website Down - ' : 'Chat request: ' ) . mb_substr( preg_replace( '/\s+/', ' ', $message ), 0, 70 );
		$body    = "New support request from the website chat\n\n"
			. "Name: $name\nEmail: $email\n"
			. ( $website ? "Church / website: $website\n" : '' )
			. ( $page ? "Sent from page: $page\n" : '' )
			. "\nMessage:\n$message\n"
			. ( $chat ? "\n--- Chat conversation ---\n$chat\n" : '' )
			. "\n--- Site details ---\n"
			. 'Site: ' . get_bloginfo( 'name' ) . ' — ' . home_url() . "\n"
			. 'Logged-in user: ' . $user->user_login . ' (' . implode( ', ', (array) $user->roles ) . ")\n"
			. 'WordPress: ' . get_bloginfo( 'version' ) . ' · PHP: ' . PHP_VERSION . "\n"
			. 'Theme: ' . $theme->get( 'Name' ) . ' ' . $theme->get( 'Version' ) . $parent . "\n"
			. 'Active plugins: ' . count( (array) get_option( 'active_plugins', array() ) ) . "\n"
			. 'Support Chat plugin: ' . self::VERSION . "\n"
			. ( $attachments ? 'Screenshots attached: ' . count( $attachments ) . "\n" : '' )
			. ( $skipped ? 'Screenshots not attached: ' . implode( '; ', $skipped ) . "\n" : '' );
		$headers = array( 'Reply-To: ' . $name . ' <' . $email . '>' );

		$sent = wp_mail( self::SUPPORT_EMAIL, $subject, $body, $headers, $attachments );
		self::remove_screenshots( $attachments, $tmp_dir );
		if ( $sent ) {
			set_transient( $cool, time() + self::TICKET_COOLDOWN, self::TICKET_COOLDOWN );
			wp_send_json_success();
		}
		wp_send_json_error( array( 'message' => 'Email could not be sent.' ), 500 );
	}

	private static function collect_screenshots() {
		$paths   = array();
		$skipped = array();
		$dir     = '';
		if ( empty( $_FILES['files'] ) || ! is_array( $_FILES['files']['name'] ) ) { // phpcs:ignore
			return array( $paths, $dir, $skipped );
		}
		$f       = $_FILES['files']; // phpcs:ignore
		$allowed = array( 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp' );
		$count   = count( $f['name'] );
		for ( $i = 0; $i < $count; $i++ ) {
			$name = sanitize_file_name( (string) $f['name'][ $i ] );
			if ( count( $paths ) >= 3 ) {
				$skipped[] = $name . ' (limit of 3)';
				continue;
			}
			if ( UPLOAD_ERR_OK !== (int) $f['error'][ $i ] || ! is_uploaded_file( $f['tmp_name'][ $i ] ) ) {
				$skipped[] = $name . ' (upload failed)';
				continue;
			}
			if ( (int) $f['size'][ $i ] > 5 * 1024 * 1024 ) {
				$skipped[] = $name . ' (over 5 MB)';
				continue;
			}
			$check = wp_check_filetype_and_ext( $f['tmp_name'][ $i ], $name, $allowed );
			if ( empty( $check['ext'] ) || false === @getimagesize( $f['tmp_name'][ $i ] ) ) { // phpcs:ignore
				$skipped[] = $name . ' (not an image)';
				continue;
			}
			if ( '' === $dir ) {
				$dir = trailingslashit( get_temp_dir() ) . 'zdsc-' . wp_generate_password( 12, false );
				if ( ! wp_mkdir_p( $dir ) ) {
					$skipped[] = $name . ' (could not be saved)';
					$dir       = '';
					continue;
				}
			}
			$base   = pathinfo( $name, PATHINFO_FILENAME );
			$target = $dir . '/' . ( $base ? $base : 'screenshot' ) . '-' . ( $i + 1 ) . '.' . $check['ext'];
			if ( move_uploaded_file( $f['tmp_name'][ $i ], $target ) ) {
				$paths[] = $target;
			} else {
				$skipped[] = $name . ' (could not be saved)';
			}
		}
		return array( $paths, $dir, $skipped );
	}

	private static function remove_screenshots( $paths, $dir ) {
		foreach ( (array) $paths as $path ) {
			if ( file_exists( $path ) ) {
				wp_delete_file( $path );
			}
		}
		if ( $dir && is_dir( $dir ) ) {
			@rmdir( $dir ); // phpcs:ignore
		}
	}

	/* ---------------- Updates from GitHub ---------------- */

	private static function update_base() {
		return ( 0 === strpos( self::UPDATE_BASE, 'https://' ) && false === strpos( self::UPDATE_BASE, 'YOUR-GITHUB-NAME' ) ) ? trailingslashit( self::UPDATE_BASE ) : '';
	}

	// Reads wordpress-plugin/update.json from GitHub Pages (cached for 6 hours).
	private static function manifest() {
		$base = self::update_base();
		if ( '' === $base ) {
			return null;
		}
		$cached = get_transient( 'zdsc_update_manifest' );
		if ( false !== $cached ) {
			return is_array( $cached ) ? $cached : null;
		}
		$res = wp_remote_get( $base . 'wordpress-plugin/update.json', array( 'timeout' => 10 ) );
		$m   = null;
		if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
			$m = json_decode( wp_remote_retrieve_body( $res ), true );
		}
		if ( is_array( $m ) && ! empty( $m['download_url'] ) && ! preg_match( '#^https?://#i', $m['download_url'] ) ) {
			$m['download_url'] = $base . ltrim( $m['download_url'], '/' );
		}
		// Only accept a download from the same GitHub Pages site.
		if ( ! is_array( $m ) || empty( $m['version'] ) || empty( $m['download_url'] ) || 0 !== strpos( $m['download_url'], $base ) ) {
			set_transient( 'zdsc_update_manifest', 'none', HOUR_IN_SECONDS );
			return null;
		}
		foreach ( array( 'icons', 'banners' ) as $group ) {
			$clean = array();
			if ( ! empty( $m[ $group ] ) && is_array( $m[ $group ] ) ) {
				foreach ( $m[ $group ] as $size => $url ) {
					$url = preg_match( '#^https?://#i', (string) $url ) ? (string) $url : $base . ltrim( (string) $url, '/' );
					if ( 0 === strpos( $url, $base ) ) {
						$clean[ sanitize_key( $size ) ] = esc_url_raw( $url );
					}
				}
			}
			$m[ $group ] = $clean;
		}
		set_transient( 'zdsc_update_manifest', $m, 6 * HOUR_IN_SECONDS );
		return $m;
	}

	// "View details" and "Get support" under the plugin on the Plugins page.
	public static function row_links( $links, $file ) {
		if ( plugin_basename( __FILE__ ) !== $file ) {
			return $links;
		}
		$has_details = false;   // WordPress sometimes adds its own "View details" link
		foreach ( $links as $l ) {
			if ( false !== strpos( $l, 'tab=plugin-information' ) ) {
				$has_details = true;
			}
		}
		if ( ! $has_details ) {
			$links[] = '<a href="' . esc_url( admin_url( 'plugin-install.php?tab=plugin-information&plugin=' . self::SLUG . '&TB_iframe=true&width=772&height=600' ) ) . '" class="thickbox open-plugin-details-modal" aria-label="More information about REACHRIGHT Support Chat">View details</a>';
		}
		$links[] = '<a href="mailto:' . esc_attr( self::SUPPORT_EMAIL ) . '">Get support</a>';
		return array_unique( $links );
	}

	private static function update_item( $m ) {
		return (object) array(
			'id'           => self::update_base(),
			'slug'         => self::SLUG,
			'plugin'       => plugin_basename( __FILE__ ),
			'new_version'  => (string) $m['version'],
			'url'          => self::update_base(),
			'package'      => (string) $m['download_url'],
			'requires'     => isset( $m['requires'] ) ? (string) $m['requires'] : '',
			'tested'       => isset( $m['tested'] ) ? (string) $m['tested'] : '',
			'requires_php' => isset( $m['requires_php'] ) ? (string) $m['requires_php'] : '',
			'icons'        => isset( $m['icons'] ) ? $m['icons'] : array(),
			'banners'      => isset( $m['banners'] ) ? $m['banners'] : array(),
		);
	}

	public static function check_update( $transient ) {
		if ( ! is_object( $transient ) || empty( $transient->checked ) ) {
			return $transient;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $transient;
		}
		$file = plugin_basename( __FILE__ );
		if ( version_compare( (string) $m['version'], self::VERSION, '>' ) ) {
			$transient->response[ $file ] = self::update_item( $m );
		} else {
			$transient->no_update[ $file ] = self::update_item( $m );
		}
		return $transient;
	}

	public static function plugin_info( $res, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
			return $res;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $res;
		}
		return (object) array(
			'name'          => 'REACHRIGHT Support Chat',
			'slug'          => self::SLUG,
			'version'       => (string) $m['version'],
			'author'        => '<a href="https://reachrightstudios.com/">REACHRIGHT Studios</a>',
			'homepage'      => self::update_base(),
			'requires'      => isset( $m['requires'] ) ? (string) $m['requires'] : '',
			'tested'        => isset( $m['tested'] ) ? (string) $m['tested'] : '',
			'requires_php'  => isset( $m['requires_php'] ) ? (string) $m['requires_php'] : '',
			'last_updated'  => isset( $m['last_updated'] ) ? (string) $m['last_updated'] : '',
			'download_link' => (string) $m['download_url'],
			'sections'      => isset( $m['sections'] ) && is_array( $m['sections'] ) ? $m['sections'] : array( 'changelog' => '' ),
			'icons'         => isset( $m['icons'] ) ? $m['icons'] : array(),
			'banners'       => isset( $m['banners'] ) ? $m['banners'] : array(),
			'author_profile'=> 'https://reachrightstudios.com/',
		);
	}

	public static function clear_update_cache() {
		delete_transient( 'zdsc_update_manifest' );
	}

	public static function maybe_force_check() {
		if ( isset( $_GET['force-check'] ) ) { // phpcs:ignore
			delete_transient( 'zdsc_update_manifest' );
		}
	}
}

ZD_Support_Chat::init();
